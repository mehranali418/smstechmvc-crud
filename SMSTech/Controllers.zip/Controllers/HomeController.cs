﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SMSTech.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        public ActionResult Index()
        {
            return View();
        }


        public ActionResult Student()
        {
            return View();
        }

        public ActionResult Admission()
        {
            return View();
        }


        public ActionResult Modren()
        {
            return View();
        }


        public ActionResult Calender()
        {
            return View();
        }

        public ActionResult ChatApp()
        {
            return View();
        }

        public ActionResult Support()
        {
            return View();
        }

        public ActionResult Employee()
        {
            return View();
        }

        public ActionResult ContactGrid()
        {
            return View();
        }

        public ActionResult ContactDetail()
        {
            return View();
        }


        public ActionResult MailBox()
        {
            return View();
        }


        public ActionResult MailBoxDetail()
        {
            return View();
        }

        public ActionResult ComposeMail()
        {
            return View();
        }

        public ActionResult Cards()
        {
            return View();
        }

        public ActionResult UserCard()
        {
            return View();
        }

        public ActionResult Button()
        {
            return View();
        }







	}
}