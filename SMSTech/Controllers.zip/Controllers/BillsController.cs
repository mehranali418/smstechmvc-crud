﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using SMSTech.Models;
using System.Net.Http;

namespace SMSTech.Controllers
{
    public class BillsController : Controller
    {
        //
        // GET: /Bills/

        HttpClient Client = new HttpClient();

        public ActionResult Index()
        {
            return View();
        }










       

     
	}
}